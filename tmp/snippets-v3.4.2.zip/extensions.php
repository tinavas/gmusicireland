<?php
/**
 * Install File
 * Does the stuff for the specific extensions
 *
 * @package         Snippets
 * @version         3.4.2
 *
 * @author          Peter van Westen <peter@nonumber.nl>
 * @link            http://www.nonumber.nl
 * @copyright       Copyright © 2014 NoNumber All Rights Reserved
 * @license         http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die;

class extensionsInstaller extends NoNumberInstallerInstaller
{
	var $name = 'Snippets';
	var $alias = 'snippets';

	function install(&$states, &$ext)
	{
		$ext = $this->name . ' (component, editor button & system plugin)';

		// COMPONENT
		$states[] = $this->installExtension($states, $this->alias, 'NoNumber ' . $this->name, 'component', array('link' => '', 'admin_menu_img' => 'components/com_' . $this->alias . '/images/icon-' . $this->alias . '.png'));

		// SYSTEM PLUGIN
		$states[] = $this->installExtension($states, $this->alias, 'System - NoNumber ' . $this->name, 'plugin');

		// EDITOR BUTTON PLUGIN
		$states[] = $this->installExtension($states, $this->alias, 'Button - NoNumber ' . $this->name, 'plugin', array('folder' => 'editors-xtd'));
	}

	// Stuff to do after installation / update
	// For Joomla 2.5
	function afterInstall()
	{
		$query = "CREATE TABLE IF NOT EXISTS `#__snippets` (
			`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
			`alias` TEXT NOT NULL,
			`name` TEXT NOT NULL,
			`description` TEXT NOT NULL,
			`content` TEXT NOT NULL,
			`params` TEXT NOT NULL,
			`published` TINYINT(1)  NOT NULL DEFAULT '0',
			`ordering` INT(11) NOT NULL DEFAULT '0',
			`checked_out` INT(11) UNSIGNED NOT NULL DEFAULT '0',
			`checked_out_time` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (`id`),
			KEY `id` (`id`,`published`)
		) DEFAULT CHARSET=utf8;";
		$this->db->setQuery($query);
		$this->db->execute();

		// disable the editor plugin on free version
		$query = "UPDATE `#__extensions`
		SET `enabled` = 0
		WHERE `type` = 'plugin'
		AND `element` = 'snippets'
		AND `folder` = 'editors-xtd'";
		$this->db->setQuery($query);
		$this->db->execute();

		// convert old J1.5 params syntax to new
		$query = $this->db->getQuery(true);
		$query->select('s.id, s.params')
			->from('#__snippets as s')
			->where('s.params REGEXP ' . $this->db->quote('^[^\{]'));
		$this->db->setQuery($query);
		$rows = $this->db->loadObjectList();
		foreach ($rows as $row)
		{
			if (empty($row->params))
			{
				continue;
			}

			$params = JRegistryFormat::getInstance('INI')->stringToObject($row->params);
			foreach ($params as $key => $val)
			{
				if (is_string($val) && !(strpos($val, '|') === false))
				{
					$params->{$key} = explode('|', $val);
				}
			}
			$query = $this->db->getQuery(true);
			$query->update('#__snippets as s')
				->set('s.params = ' . $this->db->quote(json_encode($params)))
				->where('s.id = ' . (int) $row->id);
			$this->db->setQuery($query);
			$this->db->execute();
		}
	}
}
