<?php
/**
 * Element: Categoies K2
 * DEPRECATED!
 *
 * @package         NoNumber Framework
 * @version         14.10.7
 *
 * @author          Peter van Westen <peter@nonumber.nl>
 * @link            http://www.nonumber.nl
 * @copyright       Copyright © 2014 NoNumber All Rights Reserved
 * @license         http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die;

// For backwards compatibility
require_once __DIR__ . '/k2.php';

class JFormFieldNN_CategoriesK2 extends JFormFieldNN_K2
{
}
