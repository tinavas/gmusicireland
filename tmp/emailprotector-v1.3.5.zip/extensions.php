<?php
/**
 * Extension Install File
 * Does the stuff for the specific extensions
 *
 * @package         Email Protector
 * @version         1.3.5
 *
 * @author          Peter van Westen <peter@nonumber.nl>
 * @link            http://www.nonumber.nl
 * @copyright       Copyright © 2014 NoNumber All Rights Reserved
 * @license         http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die;

class extensionsInstaller extends NoNumberInstallerInstaller
{
	var $name = 'Email Protector';
	var $alias = 'emailprotector';

	function install(&$states, &$ext)
	{
		$ext = $this->name . ' (system plugin)';

		// SYSTEM PLUGIN
		$states[] = $this->installExtension($states, $this->alias, 'System - NoNumber ' . $this->name, 'plugin');
	}

	// Stuff to do after installation / update
	function afterInstall()
	{
		// Disable the core Email Cloaking plugin
		$query = "UPDATE `#__extensions`
		SET	`enabled` = 0
		WHERE `name` = " . $this->db->quote('plg_content_emailcloak');
		$this->db->setQuery($query);
		$this->db->execute();
	}
}
