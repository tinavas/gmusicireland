<?php
/**
 * Install File
 * Does the stuff for the specific extensions
 *
 * @package         Add to Menu
 * @version         3.2.0
 *
 * @author          Peter van Westen <peter@nonumber.nl>
 * @link            http://www.nonumber.nl
 * @copyright       Copyright © 2014 NoNumber All Rights Reserved
 * @license         http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die;

class extensionsInstaller extends NoNumberInstallerInstaller
{
	var $name = 'Add to Menu';
	var $alias = 'addtomenu';

	function install(&$states, &$ext)
	{
		$ext = $this->name . ' (administrator module)';

		// ADMIN MODULE
		$states[] = $this->installExtension($states, $this->alias, 'NoNumber ' . $this->name, 'module', array('access' => '3'));
	}
}
