<?php
/**
 * Extension Install File
 * Does the stuff for the specific extensions
 *
 * @package         NoNumber Extension Manager
 * @version         4.6.0
 *
 * @author          Peter van Westen <peter@nonumber.nl>
 * @link            http://www.nonumber.nl
 * @copyright       Copyright © 2014 NoNumber All Rights Reserved
 * @license         http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die;

class extensionsInstaller extends NoNumberInstallerInstaller
{
	var $name = 'NoNumber Extension Manager';
	var $alias = 'nonumbermanager';

	function install(&$states, &$ext)
	{
		$ext = $this->name . ' (component)';

		// COMPONENT
		$states[] = $this->installExtension($states, $this->alias, 'NoNumber ' . $this->name, 'component', array('link' => '', 'admin_menu_img' => 'components/com_' . $this->alias . '/images/icon-nonumbermanager.png'));
	}

	// Stuff to do after installation / update
	function afterInstall()
	{
		// remove old licenses table
		$query = "DROP TABLE IF EXISTS `#__nonumber_licenses`;";
		$this->db->setQuery($query);
		$this->db->execute();
	}
}
