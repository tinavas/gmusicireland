<?php
/**
 * Plugin Helper File: Text
 *
 * @package         Dummy Content
 * @version         1.0.1
 *
 * @author          Peter van Westen <peter@nonumber.nl>
 * @link            http://www.nonumber.nl
 * @copyright       Copyright © 2014 NoNumber All Rights Reserved
 * @license         http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die;

/**
 * Fake Text Generator
 */
class plgSystemDummyContentHelperText
{
	var $helpers = array();

	public function __construct()
	{
		require_once __DIR__ . '/helpers.php';
		$this->helpers = plgSystemDummyContentHelpers::getInstance();
	}

	/**
	 * Generates by default by random parahraphs
	 *
	 * @param  integer $count the number of paragraphs to create
	 *
	 * @return string
	 */
	public function paragraphs($wordlist, $count = 5)
	{
		$arr = array();

		for ($i = 0; $i < $count; $i++)
		{
			$paragraph = $this->sentences($wordlist, mt_rand(2, 8), true);
			$arr[] = trim($paragraph);
		}

		return '<p>' . trim(implode('</p>' . "\n" . '<p>', $arr)) . '</p>';
	}

	/**
	 * Create by default five sentices
	 *
	 * @param  integer $count the number of sentences to create
	 *
	 * @return string
	 */
	public function sentences($wordlist, $count = 5)
	{
		$sentences = '';
		for ($i = 0; $i < $count; $i++)
		{

			//Randomly add commas to the sentence in logical places
			$rand = mt_rand(0, 3);
			if ($wordlist != 'space' && $rand === 0)
			{
				$sentence = $this->words($wordlist, mt_rand(3, 8), true);
				if (!in_array(substr(trim($sentences), -1), array('.', ',', ';', '!', '?')))
				{
					$sentence .= ',';
				}
				$sentence .= ' ' . $this->words($wordlist, mt_rand(4, 12), true);
			}
			elseif ($wordlist != 'space' && $rand === 1)
			{
				$sentence = $this->words($wordlist, mt_rand(2, 4), true);
				if (!in_array(substr(trim($sentences), -1), array('.', ',', ';', '!', '?')))
				{
					$sentence .= ',';
				}

				$sentence .= ' ' . $this->words($wordlist, mt_rand(3, 4), true);
				if (!in_array(substr(trim($sentences), -1), array('.', ',', ';', '!', '?')))
				{
					$sentence .= ',';
				}
				$sentence .= ' ' . $this->words($wordlist, mt_rand(3, 8), true);
			}
			else
			{
				$sentence = $this->words($wordlist, mt_rand(5, 20), true);
			}

			//Capitlize the first word
			$sentences .= ucfirst(trim($sentence));

			//Ocassionally use a semi-colon or exclamation mark

			if (!in_array(substr($sentences, -1), array('.', ',', ';', '!', '?')))
			{
				switch (mt_rand(0, 10))
				{
					case 0:
						$sentences .= ';';
						break;
					case 1:
						$sentences .= '!';
						break;
					default:
						$sentences .= '.';
				}
			}
			$sentences .= ' ';
		}
		$sentences = trim($sentences);

		// Make sure a semicolon is not the last character
		if (in_array(substr($sentences, -1), array(',', ';')))
		{
			$sentences = substr($sentences, 0, -1) . '.';
		}

		return $sentences;
	}

	/**
	 * Generate by default 5 random words
	 *
	 * @param  integer $count the number of words to create
	 *
	 * @return string
	 */
	public function words($wordlist, $count = 5, $finish_sentence = false)
	{
		$words = '';
		$wordlist = $this->getWordList($wordlist);
		for ($i = 0; $i < $count; $i++)
		{
			$word = $wordlist[mt_rand(0, count($wordlist) - 1)];

			// Correct stuff for list items containing multiple words
			if (strpos($word, ' ') !== false)
			{
				$word_parts = explode(' ', $word);
				$i += count($word_parts) - 1;
				if ($i >= $count && !$finish_sentence)
				{
					$diff = ($i - $count) + 1;
					$word = implode(' ', array_slice($word_parts, 0, count($word_parts) - $diff));
				}
			}
			$words .= $word . ' ';
		}

		return trim($words);
	}

	/**
	 * Generate by default five capitilized words
	 *
	 * @param  integer $count the number of words to create
	 *
	 * @return string
	 */
	public function title($wordlist, $count = 5)
	{
		$title = $this->words($wordlist, $count, true);

		return ucwords($title);
	}

	/**
	 * Generates a title inside a heading element
	 *
	 * @return string
	 */
	public function heading($wordlist, $count = 5, $level = 1)
	{
		return '<h' . (int) $level . '>' . $this->title($wordlist, $count) . '</h' . (int) $level . '>';
	}

	/**
	 * Generates a list of elements
	 *
	 * @return string
	 */
	public function alist($wordlist, $count = 0, $type = '')
	{
		$types = array('ul', 'ol');
		$type = $type ?: $types[mt_rand(0, 1)];

		$count = ($count > 1 && $count != 'random') ? $count : mt_rand(2, 10);

		$html = array();
		$html[] = '<' . $type . '>';
		for ($i = 0; $i < $count; $i++)
		{

			$html[] = '<li>' . $this->words($wordlist, mt_rand(3, 10), true) . '</li>';
		}
		$html[] = '</' . $type . '>';

		return implode('', $html);
	}

	/**
	 * Generates fake email address
	 *
	 * @return string
	 */
	public function email($wordlist, $count = 0)
	{
		$endings = array('com', 'net', 'org', 'co.uk', 'nl');
		if (mt_rand(0, 5) === 0)
		{
			$email = $this->words($wordlist, 1);
			if (mt_rand(0, 2) === 0)
			{
				$email .= '+';
			}
			else
			{
				$email .= '.';
			}
			$email .= $this->words($wordlist, 1);
		}
		else
		{
			$email = str_replace(" ", "", $this->words($wordlist, mt_rand(1, 2)));
		}
		$email .= '@';
		if (mt_rand(0, 3) === 0)
		{
			$email .= str_replace(" ", "-", $this->words($wordlist, 2));
		}
		else
		{
			$email .= str_replace(" ", "", $this->words($wordlist, mt_rand(1, 2)));
		}
		$email .= '.' . $endings[mt_rand(0, 3)];

		return $email;
	}

	/**
	 * Generates a kitchen sink (mixed headings/paragraphs/lists
	 *
	 * @return string
	 */
	public function kitchenSink($wordlist, $count = 0)
	{
		$html = array();

		$numbers = array(3, 2, 1);

		$numbers = array_merge($numbers, array_fill(0, 4, 0));
		$numbers = array_slice($numbers, 0, mt_rand(3, 7), true);
		shuffle($numbers);

		$heading = 0;
		foreach ($numbers as $number)
		{
			$html[] = $this->kitchenSinkItem($wordlist, $heading, $number);
		}

		return implode('', $html);
	}

	public function kitchenSinkItem($wordlist, &$heading, $number = 0)
	{
		$html = array();

		$heading = max(1, rand($heading - 1, $heading + 1));
		$html[] = $this->heading($wordlist, mt_rand(2, 5), $heading);

		$number = $number ?: mt_rand(1, 4);
		switch ($number)
		{
			case 1:
				$html[] = $this->paragraphs($wordlist, mt_rand(1, 3));
				break;
			case 2:
				$html[] = $this->paragraphs($wordlist, mt_rand(0, 1));
				$html[] = $this->alist($wordlist, mt_rand(2, 6));
				$html[] = $this->paragraphs($wordlist, mt_rand(0, 1));
				break;
			case 3:
				$html[] = $this->paragraphs($wordlist, mt_rand(1, 2));
				$email = $this->email($wordlist);
				$html[] = '<a href="mailto:' . $email . '">' . $email . '</a>';
				break;
			case 4:
				$html[] = $this->paragraphs($wordlist, mt_rand(0, 1));
				$options = (object) array(
					'width'  => mt_rand(10, 60) * 10,
					'height' => mt_rand(10, 60) * 10,
				);

				$html[] = $this->helpers->get('image')->render($options);
				$html[] = $this->paragraphs($wordlist, mt_rand(0, 1));
				break;
		}

		return implode('', $html);
	}

	public function getWordList($type)
	{
		$type = preg_replace('#[^a-z0-9]#', '', strtolower($type));
		$type = rtrim($type, 'ipsum');
		switch ($type)
		{

			// Taken from https://github.com/barowen/a-fishier-lorem-ipsum-generator
			case 'lorem':
			default :
				return array('a', 'ac', 'accumsan', 'ad', 'adipiscing', 'aenean', 'aliquam', 'aliquet', 'amet', 'ante', 'aptent', 'arcu', 'at', 'auctor', 'augue', 'bibendum', 'blandit', 'class', 'commodo', 'condimentum', 'congue', 'consectetur', 'consequat', 'conubia', 'convallis', 'cras', 'cubilia', 'curabitur', 'curae', 'cursus', 'dapibus', 'diam', 'dictum', 'dictumst', 'dolor', 'donec', 'dui', 'duis', 'egestas', 'eget', 'eleifend', 'elementum', 'elit', 'enim', 'erat', 'eros', 'est', 'et', 'etiam', 'eu', 'euismod', 'facilisis', 'fames', 'faucibus', 'felis', 'fermentum', 'feugiat', 'fringilla', 'fusce', 'gravida', 'habitant', 'habitasse', 'hac', 'hendrerit', 'himenaeos', 'iaculis', 'id', 'imperdiet', 'in', 'inceptos', 'integer', 'interdum', 'ipsum', 'justo', 'lacinia', 'lacus', 'laoreet', 'lectus', 'leo', 'libero', 'ligula', 'litora', 'lobortis', 'lorem', 'luctus', 'maecenas', 'magna', 'malesuada', 'massa', 'mattis', 'mauris', 'metus', 'mi', 'molestie', 'mollis', 'morbi', 'nam', 'nec', 'neque', 'netus', 'nibh', 'nisi', 'nisl', 'non', 'nostra', 'nulla', 'nullam', 'nunc', 'odio', 'orci', 'ornare', 'pellentesque', 'per', 'pharetra', 'phasellus', 'placerat', 'platea', 'porta', 'porttitor', 'posuere', 'potenti', 'praesent', 'pretium', 'primis', 'proin', 'pulvinar', 'purus', 'quam', 'quis', 'quisque', 'rhoncus', 'risus', 'rutrum', 'sagittis', 'sapien', 'scelerisque', 'sed', 'sem', 'semper', 'senectus', 'sit', 'sociosqu', 'sodales', 'sollicitudin', 'suscipit', 'suspendisse', 'taciti', 'tellus', 'tempor', 'tempus', 'tincidunt', 'torquent', 'tortor', 'tristique', 'turpis', 'ullamcorper', 'ultrices', 'ultricies', 'urna', 'ut', 'varius', 'vehicula', 'vel', 'velit', 'venenatis', 'vestibulum', 'vitae', 'vivamus', 'viverra', 'volutpat', 'vulputate');
		}
	}
}
