<?php
/**
 * Install File
 * Does the stuff for the specific extensions
 *
 * @package         Advanced Template Manager
 * @version         1.1.7
 *
 * @author          Peter van Westen <peter@nonumber.nl>
 * @link            http://www.nonumber.nl
 * @copyright       Copyright © 2014 NoNumber All Rights Reserved
 * @license         http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die;

class extensionsInstaller extends NoNumberInstallerInstaller
{
	var $name = 'Advanced Template Manager ';
	var $alias = 'advancedtemplates';

	function install(&$states, &$ext)
	{
		$ext = $this->name . ' (admin component & system plugin)';

		// COMPONENT
		$states[] = $this->installExtension($states, $this->alias, 'NoNumber ' . $this->name, 'component', array('link' => '', 'admin_menu_link' => ''));

		// SYSTEM PLUGIN
		$states[] = $this->installExtension($states, $this->alias, 'System - NoNumber ' . $this->name, 'plugin', array('folder' => 'system'));
	}

	// Stuff to do before installation / update
	function beforeInstall()
	{
		$this->fixFileVersions();
	}

	// Stuff to do after installation / update
	function afterInstall()
	{
		// main table
		$query = "CREATE TABLE IF NOT EXISTS `#__advancedtemplates` (
			`styleid` INT(11) UNSIGNED NOT NULL DEFAULT '0',
			`asset_id` INT(10) UNSIGNED NOT NULL DEFAULT '0',
			`params` TEXT NOT NULL,
			PRIMARY KEY (`styleid`)
		) DEFAULT CHARSET=utf8;";
		$this->db->setQuery($query);
		$this->db->execute();

		$query = $this->db->getQuery(true);

		// hide admin menu
		$query->clear()
			->delete('#__menu')
			->where($this->db->quoteName('path') . ' = ' . $this->db->quote('advancedtemplates'))
			->where($this->db->quoteName('type') . ' = ' . $this->db->quote('component'))
			->where($this->db->quoteName('client_id') . ' = 1');
		$this->db->setQuery($query);
		$this->db->execute();
	}

	// Fix wrong version numbers
	function fixFileVersions()
	{
		$this->fixFileVersionsByFile(JPATH_ADMINISTRATOR . '/components/com_advancedtemplates/advancedtemplates.xml');
	}
}
